# Our Little Adventures ❤️

A free, static couple's bucket-list website.

## Run it
Open `index.html` in a browser.

## Put it online for free
Upload this folder/repository to GitHub and enable GitHub Pages, or deploy it to Cloudflare Pages.

## Important
The current version stores the bucket list in the browser's localStorage. That means it is free and requires no backend, but changes are not automatically shared between two different phones/computers.

For true two-person syncing, the next version can connect the same design to Supabase/Firebase free tier.
